<?php return array('dependencies' => array('wc-blocks-registry', 'wp-element'), 'version' => 'c7d3a2dbec878ecf2f26');
