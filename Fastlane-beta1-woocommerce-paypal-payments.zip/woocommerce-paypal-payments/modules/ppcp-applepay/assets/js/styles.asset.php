<?php return array('dependencies' => array(), 'version' => '679c2311dfd08b0b7fa9');
