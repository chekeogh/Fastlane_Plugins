<?php return array('dependencies' => array(), 'version' => '4910e4abf3d165a8c20f');
