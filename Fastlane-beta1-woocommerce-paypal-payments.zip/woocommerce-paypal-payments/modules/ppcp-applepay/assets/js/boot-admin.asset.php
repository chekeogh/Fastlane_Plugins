<?php return array('dependencies' => array(), 'version' => '0e3dcc175eca7bcfd691');
