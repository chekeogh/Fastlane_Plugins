import BaseHandler from "./BaseHandler";

class CartBlockHandler extends BaseHandler {

}

export default CartBlockHandler;
