import BaseHandler from "./BaseHandler";

class MiniCartHandler extends BaseHandler {

}

export default MiniCartHandler;
