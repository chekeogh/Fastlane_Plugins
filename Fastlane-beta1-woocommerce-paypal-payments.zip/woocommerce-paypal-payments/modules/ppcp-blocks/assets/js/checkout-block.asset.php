<?php return array('dependencies' => array('react', 'wc-blocks-registry', 'wp-element'), 'version' => '8f10007ab683305b648b');
