<?php return array('dependencies' => array('react', 'wc-blocks-registry', 'wp-element'), 'version' => 'b804a0aacfebde38ffc0');
