<?php return array('dependencies' => array(), 'version' => '892236f57223fb24dfec');
