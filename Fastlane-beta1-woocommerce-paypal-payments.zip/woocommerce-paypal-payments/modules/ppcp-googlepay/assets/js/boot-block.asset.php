<?php return array('dependencies' => array('wc-blocks-registry', 'wp-element'), 'version' => '56d282c17c7749c4217c');
