<?php return array('dependencies' => array(), 'version' => '68288b41df825237fb40');
