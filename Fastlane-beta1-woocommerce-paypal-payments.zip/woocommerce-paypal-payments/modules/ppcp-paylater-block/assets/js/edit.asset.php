<?php return array('dependencies' => array(), 'version' => 'cb65abbdd42d24cec23e');
