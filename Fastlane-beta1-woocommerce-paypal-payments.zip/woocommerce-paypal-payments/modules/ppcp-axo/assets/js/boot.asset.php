<?php return array('dependencies' => array(), 'version' => '68898323d7e728adaf51');
