<?php return array('dependencies' => array(), 'version' => 'b13c9fe47c48858717ae');
